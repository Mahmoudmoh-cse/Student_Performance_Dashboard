-- models/subjects.sql

select 1 as subject_id, 'Math' as subject_name
union all
select 2, 'Physics'
union all
select 3, 'Chemistry'
union all
select 4, 'Biology'
union all
select 5, 'English'
union all
select 6, 'History'

